import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import './App.css'
import Home from './pages/Home'
import Scheduling from './pages/scheduling';

// import Login from './pages/Login'
// import Signup from './pages/Signup'

function App() {
  return (
    <>
      <Router>
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/scheduling" element={<Scheduling />} />
        </Routes>
      </Router>
    </>
  )
}

export default App



