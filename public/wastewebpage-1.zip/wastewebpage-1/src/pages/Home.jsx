import Layout from "../Component/Layout"
import HomePageHero from "./HomePageHero"
function Home() {
  return (
    <Layout>
           <HomePageHero/>
    </Layout>
  )
}

export default Home