import Layout from "../Component/Layout"


function Product() {
  return (
    <Layout>
         <div>Product</div>
    </Layout>
    
  )
}

export default Product