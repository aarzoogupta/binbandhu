import Layout from "../Component/Layout"
function Scheduling() {
  return (
    <Layout>
        <div>Scheduling</div>
    </Layout>
  )
}

export default Scheduling