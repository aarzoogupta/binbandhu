import Layout from "../Component/Layout"


function SnapNsell() {
  return (
    <Layout>
      <div>SnapNsell</div>
    </Layout>
  )
}

export default SnapNsell