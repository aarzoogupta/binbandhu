import Layout from "../Component/Layout"


function Edu() {
  return (
    <Layout>
       <div>Edu</div>
    </Layout>
  )
}

export default Edu